﻿using System.Runtime.InteropServices;

Console.WriteLine("=== DLL 加载优先级测试 ===");
Console.WriteLine($"当前进程架构: {(Environment.Is64BitProcess ? "x64" : "x86")}");
Console.WriteLine($"应用程序目录: {AppDomain.CurrentDomain.BaseDirectory}");
Console.WriteLine();

TestMethod1_SetDillDirectory();
Console.WriteLine();

TestMethod2_LoadLibrary();
Console.WriteLine();

TestMethod3_NativeLibrary();
Console.WriteLine();

static void TestMethod1_SetDillDirectory()
{
    Console.WriteLine("方法1: 使用 SetDllDirectory 控制搜索路径");

    var baseDir = AppDomain.CurrentDomain.BaseDirectory;
    var archDir = Path.Combine(baseDir, Environment.Is64BitProcess ? "x64" : "x86");
    if (Directory.Exists(archDir))
    {
        Console.WriteLine($"设置 DLL 搜索目录: {archDir}");
        if (NativeMethods.SetDllDirectory(archDir))
        {
            try
            {
                var ptr = NativeMethods.Sqlite3LibVersion();
                var result = Marshal.PtrToStringAnsi(ptr) ?? "未知版本";
                Console.WriteLine($"DLL 加载成功，返回值: {result}");
            }
            catch (DllNotFoundException ex)
            {
                Console.WriteLine($"加载失败: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"其他错误: {ex.Message}");
            }
            finally
            {
                NativeMethods.SetDllDirectory(null); // 清除设置
                Console.WriteLine("已清除 DLL 搜索路径设置");
            }
        }
        else
        {
            Console.WriteLine($"设置 DLL 目录失败: {Marshal.GetLastWin32Error()}");
        }
    }
    else
    {
        Console.WriteLine($"警告: 架构目录不存在: {archDir}");
        Console.WriteLine("将尝试在当前目录加载 DLL...");
        try
        {
            var ptr = NativeMethods.Sqlite3LibVersion();
            var result = Marshal.PtrToStringAnsi(ptr) ?? "未知版本";
            Console.WriteLine($"从当前目录加载成功，返回值: {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"从当前目录加载失败: {ex.Message}");
        }
    }
}

static void TestMethod2_LoadLibrary()
{
    Console.WriteLine("方法2: 使用 LoadLibrary 手动加载");

    var baseDir = AppDomain.CurrentDomain.BaseDirectory;
    string[] possiblePaths =
    {
        Path.Combine(baseDir, Environment.Is64BitProcess ? "x64" : "x86", "sqlite3.dll"),
        Path.Combine(baseDir, "sqlite3.dll"),
        "sqlite3.dll"
    };

    foreach (var dllPath in possiblePaths)
    {
        Console.WriteLine($"尝试从路径加载: {dllPath}");
        var hModule = NativeMethods.LoadLibrary(dllPath);
        if (hModule != IntPtr.Zero)
        {
            Console.WriteLine("LoadLibrary 成功");
            try
            {
                // 获取函数地址
                var procAddr = NativeMethods.GetProcAddress(hModule, "sqlite3_libversion");
                if (procAddr != IntPtr.Zero)
                {
                    Console.WriteLine("找到 sqlite3_libversion 函数地址");
                    // 创建委托调用函数
                    var func = Marshal.GetDelegateForFunctionPointer<Sqlite3LibVersionDelegate>(procAddr);
                    var ptr = func();
                    var result = Marshal.PtrToStringAnsi(ptr) ?? "未知版本";
                    Console.WriteLine($"通过 LoadLibrary 调用成功，返回值: {result}");
                }
                else
                {
                    Console.WriteLine("未找到 sqlite3_libversion 函数");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"调用函数时出错: {ex.Message}");
            }
            finally
            {
                NativeMethods.FreeLibrary(hModule);
                Console.WriteLine("已释放库");
            }

            break;
        }
        else
        {
            var error = Marshal.GetLastWin32Error();
            Console.WriteLine($"LoadLibrary 失败，错误代码: {error}");
        }
    }
}

static void TestMethod3_NativeLibrary()
{
    Console.WriteLine("方法3: 使用 .NET NativeLibrary 类");

    string[] possibleNames = { "sqlite3.dll", "sqlite3" };

    foreach (var libName in possibleNames)
    {
        try
        {
            Console.WriteLine($"尝试加载: {libName}");
            var handle = NativeLibrary.Load(libName);
            Console.WriteLine("NativeLibrary.Load 成功");

            try
            {
                // 获取函数指针
                if (NativeLibrary.TryGetExport(handle, "sqlite3_libversion", out var funcPtr))
                {
                    Console.WriteLine("找到 sqlite3_libversion 导出函数");
                    // 创建委托调用函数
                    var func = Marshal.GetDelegateForFunctionPointer<Sqlite3LibVersionDelegate>(funcPtr);
                    var ptr = func();
                    var result = Marshal.PtrToStringAnsi(ptr) ?? "未知版本";
                    Console.WriteLine($"通过 NativeLibrary 调用成功，返回值: {result}");
                }
                else
                {
                    Console.WriteLine("未找到 sqlite3_libversion 导出函数");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"调用函数时出错: {ex.Message}");
            }
            finally
            {
                NativeLibrary.Free(handle);
                Console.WriteLine("已释放 NativeLibrary");
            }

            break;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"NativeLibrary.Load 失败: {ex.Message}");
        }
    }
}

// 委托定义
delegate nint Sqlite3LibVersionDelegate();

static class NativeMethods
{
    // 系统 API
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool SetDllDirectory(string? lpPathName);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr LoadLibrary(string lpLibFileName);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool FreeLibrary(IntPtr hLibModule);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

    [DllImport("sqlite3.dll", EntryPoint = "sqlite3_libversion", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    public static extern nint Sqlite3LibVersion();
}